Kernelspace
===========

Client *user_space* programm test_util use our driver to write "Hello module!" to a *kernel space* buffer in driver. And read data from driver buffer )  
